# utils.py

import librosa
import os
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.externals import joblib  # Import joblib for loading models
from keras.models import load_model


def read_wav_data(folder_path):
    """
    Reads all .wav files in a given folder and returns a list of arrays containing the audio data.

    Args:
        folder_path: The path to the folder containing the .wav files.

    Returns:
        A list of arrays containing the audio data for each .wav file.
    """
    audio_data = []
    sample_rates = []
    for filename in os.listdir(folder_path):
        if filename.endswith(".wav"):
            file_path = os.path.join(folder_path, filename)
            audio, sample_rate = librosa.load(file_path, sr=None)
            audio_data.append(np.array(audio))
            sample_rates.append(sample_rate)

    return audio_data, sample_rates

def denoise_audio(audio_data):
    """
    Denoises the given audio data using a simple moving average filter.

    Args:
        audio_data: A list of arrays containing the audio data.

    Returns:
        A list of arrays containing the denoised audio data.
    """
    denoised_audio = []
    for audio in audio_data:
        window_size = 500
        weights = np.ones(window_size) / window_size
        denoised_audio.append(np.convolve(audio, weights, mode='same'))

    return denoised_audio

def create_melspec(audio_data, sr=4000):
    """
    Creates a mel spectrogram for each audio file in the given list.

    Args:
        audio_data: A list of arrays containing the audio data.
        sr: Sample rate of the audio data (default is 4000).

    Returns:
        A list of mel spectrograms.
    """
    melspecs = []
    for audio in audio_data:
        melspec = librosa.feature.melspectrogram(y=audio, sr=sr, hop_length=64, win_length=125)
        melspecs.append(melspec)

    return melspecs

def reshape_for_conv2d(melspecs):
    """
    Reshapes the input data for Conv2D.

    Args:
        melspecs: A list of mel spectrograms.

    Returns:
        A 4D numpy array suitable for Conv2D input.
    """
    melspecs = np.array(melspecs)
    return melspecs.reshape(melspecs.shape[0], melspecs.shape[1], melspecs.shape[2], 1)

def check_csv_columns(df):
    """
    Checks if the DataFrame contains the required columns with the correct data types.

    Args:
        df: The DataFrame to check.

    Returns:
        True if the DataFrame is valid, otherwise raises a ValueError.
    """
    required_columns = {
        'AGE': 'int64',
        'PackHistory': 'float64',
        'MWT1': 'float64',
        'MWT2': 'float64',
        'MWT1Best': 'float64',
        'FEV1': 'float64',
        'FEV1PRED': 'float64',
        'FVC': 'float64',
        'FVCPRED': 'int64',
        'CAT': 'int64',
        'HAD': 'float64',
        'SGRQ': 'float64',
        'AGEquartiles': 'int64',
        'copd': 'int64',
        'gender': 'int64',
        'smoking': 'int64',
        'Diabetes': 'int64',
        'muscular': 'int64',
        'hypertension': 'int64',
        'AtrialFib': 'int64',
        'IHD': 'int64'
    }

    for col, dtype in required_columns.items():
        if col not in df.columns:
            raise ValueError(f"Missing required column: {col}")
        if df[col].dtype != dtype:
            raise ValueError(f"Incorrect data type for column {col}. Expected {dtype}, got {df[col].dtype}")

    return True

def encode_target(df):
    """
    Encodes the COPD severity target variable.

    Args:
        df: The DataFrame containing the target variable.

    Returns:
        The DataFrame with the encoded target variable.
    """
    severity_mapping = {'MILD': 0, 'MODERATE': 1, 'SEVERE': 2, 'VERY SEVERE': 3}
    df['COPDSEVERITY'] = df['COPDSEVERITY'].map(severity_mapping)
    return df

def scale_data(df):
    """
    Scales the features of the DataFrame.

    Args:
        df: The DataFrame to scale.

    Returns:
        The scaled DataFrame.
    """
    scaler = StandardScaler()
    features = df.columns[df.columns != 'COPDSEVERITY']
    df[features] = scaler.fit_transform(df[features])
    return df

def load_model(model_path):
    """
    Loads a model from a .sav file.

    Args:
        model_path: The path to the .sav file containing the saved model.

    Returns:
        The loaded model.
    """
    if not os.path.isfile(model_path):
        raise FileNotFoundError(f"Model file not found: {model_path}")
    
    try:
        model = joblib.load(model_path)
        return model
    except Exception as e:
        raise RuntimeError(f"Error loading model from {model_path}: {e}")

def predict_severity(model, X):
    """
    Predicts the COPD severity using the specified model.

    Args:
        model: The trained model.
        X: The input data.

    Returns:
        The predicted severity labels.
    """
    return model.predict(X)

def predict_audio_severity(model_path, audio_data):
    """
    Loads a Keras model from an .h5 file and uses it to predict the severity of COPD based on audio data.

    Args:
        model_path: The path to the .h5 file containing the saved Keras model.
        audio_data: The audio data to be predicted. Should be in the shape (n, 128, 626, 1).

    Returns:
        An integer representing the predicted severity (0 or 1).
    """
    # Load the Keras model
    try:
        model = load_model(model_path)
    except Exception as e:
        raise RuntimeError(f"Error loading model from {model_path}: {e}")
    
    # Ensure audio_data is a numpy array and in the correct shape
    audio_data = np.array(audio_data)
    
    if len(audio_data.shape) != 4 or audio_data.shape[-1] != 1:
        raise ValueError("audio_data must be a 4D array with shape (n, 128, 626, 1)")

    # Predict using the model
    predictions = model.predict(audio_data)
    
    # Return the prediction as an integer (0 or 1)
    # Assuming binary classification (0 or 1)
    return int(np.round(predictions[0][0]))  # Adjust if you need a different way to handle multiple outputs
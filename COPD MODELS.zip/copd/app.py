import streamlit as st
import pandas as pd
import os
import tempfile
import random
from utils import *

# Set page configuration
st.set_page_config(page_title="COPD Severity Checker", layout="centered")

BASE_PATH = os.getcwd()

# Custom CSS for background image and H1 styling
st.markdown("""
    <style>
    .main {
        background-image: url('/Users/mac/Documents/Quantum/medical-logo.png');  /* Replace with your image URL */
        background-size: cover;
        filter: blur(8px);
        -webkit-filter: blur(8px);
    }
    .overlay {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        text-align: center;
    }
    h1 {
        color: red;
        font-weight: bold;
    }
    .stApp {
        position: relative;
        overflow: hidden;
    }
    .stApp .main {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        z-index: -1;
    }
    .stApp .overlay {
        position: relative;
        z-index: 1;
    }
    </style>
    """, unsafe_allow_html=True)

# Display the overlay message
st.markdown('<div class="overlay"><h1>CHECK FOR CHRONIC OBSTRUCTIVE PULMONARY DISEASE SEVERITY</h1></div>', unsafe_allow_html=True)

# Phase 1: Input Number of Patients
st.title("COPD Severity Prediction")

st.write("Please upload one audio file (.wav) and one CSV file for the patient data.")

# Phase 2: Upload Files
uploaded_csv = st.file_uploader("Upload CSV file of patient data:", type=["csv"])
uploaded_audio = st.file_uploader("Upload a .wav file:", type=["wav"])

# Button to trigger the prediction process
if st.button("Predict Severity"):
    if uploaded_csv and uploaded_audio:
        try:
            st.write("Reading CSV file...")
            patient_data = pd.read_csv(uploaded_csv)
            check_csv_columns(patient_data)
            st.write("Patient Data:")
            st.write(patient_data)
        except Exception as e:
            st.error(f"Error reading the CSV file: {e}")

        st.write("Uploaded Audio File:")
        
        # Save uploaded audio to a temporary directory
        temp_dir = tempfile.mkdtemp()
        audio_path = os.path.join(temp_dir, uploaded_audio.name)
        with open(audio_path, "wb") as f:
            f.write(uploaded_audio.read())
        
        try:
            st.write("Processing audio file...")
            audio_data, _ = read_wav_data(temp_dir)
            denoised_audio = denoise_audio(audio_data)
            melspecs = create_melspec(denoised_audio)
            input_data = reshape_for_conv2d(melspecs)
            
            st.write("Loading audio model...")
            audio_model_path = "model.keras"
            audio_severity = predict_audio_severity(audio_model_path, input_data[0])  # Single patient, single prediction
            st.write("Audio data processed:")
            st.write(f"Audio severity prediction: {audio_severity}")
        except Exception as e:
            st.error(f"Error processing audio file: {e}")

        # Model selection
        model_choice = st.selectbox("Choose a model for predicting severity:", 
                                    ("Logistic Regression Model", "Gradient Boosting Model", 
                                     "Decision Tree Model", "Random Forest Model"))

        if model_choice:
            model_choice = "_".join(model_choice.lower().split(" "))
            model_path = f"{BASE_PATH}/{model_choice}.sav"
            predictions = predict_severity(model_path, patient_data)

            st.write("COPD Severity Predictions:")
            # Final decision logic
            severity_messages = []
            for i, prediction in enumerate(predictions):
                if i == 0:  # Since we're only handling one patient
                    audio_prediction = audio_severity
                if prediction in [0, 1] and audio_prediction == 0:
                    severity_messages.append(f"{['MILD', 'MODERATE'][prediction]} AND OKAY")
                elif prediction in [0, 1] and audio_prediction == 1:
                    severity_messages.append(f"{['MILD', 'MODERATE'][prediction]} BUT BE WATCHFUL AND GET TESTED")
                elif prediction in [2, 3] and audio_prediction == 0:
                    severity_messages.append("SEVERE")
                elif prediction in [2, 3] and audio_prediction == 1:
                    severity_messages.append("VERY SEVERE")

            patient_data["FinalSeverity"] = severity_messages
            st.write("Final COPD Severity Assessment:")
            st.dataframe(patient_data)
        
        # Cleanup temporary files
        os.remove(audio_path)
        os.rmdir(temp_dir)
    else:
        st.error("Please upload both CSV and audio files.")
else:
    pass